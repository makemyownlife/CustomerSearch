
项目目的：OSChina 实现全文搜索的简单封装框架

License: Public Domain

包含内容：

- 重建索引工具 -> IndexRebuilder.java
- 增量构建索引工具 -> IndexUpdater.java
- 全文搜索框架